import BlogPagination, { getStaticProps } from "./page/[slug]";
export { getStaticProps };
export default BlogPagination;
